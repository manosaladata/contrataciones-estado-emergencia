library(testthat)
library(contratosemergencia)

test_check("contratosemergencia")

library(testthat)
library(minvers)

test_check("minvers")

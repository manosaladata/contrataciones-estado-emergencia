#' OpenContracts package
#' Contiene funciones para analizar los contratos directos por Covid en Perú
#'
#' @docType package
#'
#' @author Abner Francisco Casallo Trauco \email{abner.casallo@unmsm.edu.pe}
#'
#' @name opencontracts
NULL


